

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto bg-white rounded-xl shadow p-8 mt-8">
    <h1 class="text-2xl font-bold text-[#2E338C] mb-6">Nuevo Servicio</h1>
    <form action="<?php echo e(route('servicios.store')); ?>" method="POST" class="space-y-5">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nombre" class="block text-sm font-medium text-[#2E338C] mb-1">Nombre</label>
            <input type="text" name="nombre" class="w-full rounded-lg border border-[#2E338C]/20 focus:border-[#2E338C] focus:ring-2 focus:ring-[#2E338C]/30 px-4 py-2" required>
        </div>
        <div>
            <label for="precio" class="block text-sm font-medium text-[#2E338C] mb-1">Precio</label>
            <input type="number" step="0.01" name="precio" class="w-full rounded-lg border border-[#2E338C]/20 focus:border-[#2E338C] focus:ring-2 focus:ring-[#2E338C]/30 px-4 py-2" required>
        </div>
        <div class="flex gap-3 mt-6">
            <button type="submit" class="px-6 py-2 rounded-lg bg-[#F2541B] text-white font-semibold shadow transition hover:bg-[#d9430f] focus:outline-none focus:ring-2 focus:ring-[#F2541B] focus:ring-offset-2">Guardar</button>
            <a href="<?php echo e(route('servicios.index')); ?>" class="px-6 py-2 rounded-lg bg-[#2E338C] text-white font-semibold shadow transition hover:bg-[#23277a]">Cancelar</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mgzejflo/zaas.expandeya.com/resources/views/servicios/create.blade.php ENDPATH**/ ?>