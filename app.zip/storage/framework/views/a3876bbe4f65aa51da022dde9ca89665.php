

<?php $__env->startSection('content'); ?>
<div class="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
  <div>
    <h1 class="text-3xl font-bold text-[#2E338C]">Reportes</h1>
    <p class="text-[#2E338C] text-sm">Listado de todos los reportes</p>
  </div>
  <a href="<?php echo e(route('reportes.create')); ?>" class="inline-flex items-center gap-2 px-6 py-2 rounded-lg bg-[#F2541B] text-white font-semibold shadow transition hover:bg-[#d9430f] focus:outline-none focus:ring-2 focus:ring-[#F2541B] focus:ring-offset-2">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path d="M12 4v16m8-8H4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    Nuevo Reporte
  </a>
</div>
<div class="overflow-x-auto rounded-xl shadow border border-[#2E338C]/10 bg-white">
  <table class="min-w-full divide-y divide-[#2E338C]/10">
    <thead class="bg-[#2E338C] text-white">
      <tr>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">ID</th>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Título</th>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Descripción</th>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Acciones</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-[#2E338C]/10">
      <?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr class="hover:bg-[#F2541B]/10 transition">
        <td class="px-4 py-2"><?php echo e($reporte->id); ?></td>
        <td class="px-4 py-2 font-semibold text-[#2E338C]"><?php echo e($reporte->titulo); ?></td>
        <td class="px-4 py-2"><?php echo e($reporte->descripcion); ?></td>
        <td class="px-4 py-2 flex gap-2">
          <a href="<?php echo e(route('reportes.edit', $reporte)); ?>" class="px-3 py-1 rounded bg-[#2E338C] text-white text-xs font-medium hover:bg-[#23277a] transition">Editar</a>
          <form action="<?php echo e(route('reportes.destroy', $reporte)); ?>" method="POST" class="inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="px-3 py-1 rounded bg-[#F2541B] text-white text-xs font-medium hover:bg-[#d9430f] transition">Eliminar</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\SaaS\resources\views/reportes/index.blade.php ENDPATH**/ ?>