

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto bg-white rounded-xl shadow p-8 mt-8">
    <h1 class="text-2xl font-bold text-[#2E338C] mb-6">Dashboard Ejecutivo</h1>
    
    <?php if(app()->environment('local')): ?>
    <script>
        console.log('Ventas por mes:', <?php echo json_encode($ventasPorMes, 15, 512) ?>);
        console.log('Productos más vendidos:', <?php echo json_encode($productosMasVendidos, 15, 512) ?>);
        console.log('Tickets por estado:', <?php echo json_encode($ticketsPorEstado, 15, 512) ?>);
        console.log('Citas por mes:', <?php echo json_encode($citasPorMes, 15, 512) ?>);
        console.log('Productos más pagados:', <?php echo json_encode($productosMasPagados, 15, 512) ?>);
        console.log('Servicios más pagados:', <?php echo json_encode($serviciosMasPagados, 15, 512) ?>);
    </script>
    <?php endif; ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10">
        <div class="bg-[#2E338C]/10 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#2E338C]"><?php echo e($totalUsuarios); ?></div>
            <div class="text-[#2E338C]">Usuarios</div>
        </div>
        <div class="bg-[#F2541B]/10 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#F2541B]"><?php echo e($totalClientes); ?></div>
            <div class="text-[#F2541B]">Clientes</div>
        </div>
        <div class="bg-[#4BC0C0]/10 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#4BC0C0]"><?php echo e($totalProductos); ?></div>
            <div class="text-[#4BC0C0]">Productos</div>
        </div>
        <div class="bg-[#FFCE56]/10 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#FFCE56]"><?php echo e($totalServicios); ?></div>
            <div class="text-[#FFCE56]">Servicios</div>
        </div>
        <div class="bg-[#36A2EB]/10 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#36A2EB]"><?php echo e($totalPagos); ?></div>
            <div class="text-[#36A2EB]">Pagos</div>
        </div>
        <div class="bg-[#23277a]/10 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#23277a]"><?php echo e($totalTickets); ?></div>
            <div class="text-[#23277a]">Tickets</div>
        </div>
        <div class="bg-[#F2541B]/20 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#F2541B]"><?php echo e($totalCitas); ?></div>
            <div class="text-[#F2541B]">Citas</div>
        </div>
        <div class="bg-[#2E338C]/20 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#2E338C]"><?php echo e($totalReportes); ?></div>
            <div class="text-[#2E338C]">Reportes</div>
        </div>
        <div class="bg-[#4BC0C0]/20 rounded-lg p-4 text-center">
            <div class="text-3xl font-bold text-[#4BC0C0]"><?php echo e($totalContactos); ?></div>
            <div class="text-[#4BC0C0]">Contactos</div>
        </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
        <div>
            <h2 class="text-lg font-semibold mb-2">Ventas por Mes</h2>
            <?php if(count($ventasPorMes)): ?>
                <canvas id="barChart"></canvas>
            <?php else: ?>
                <div class="text-gray-500">No hay datos para mostrar.</div>
            <?php endif; ?>
        </div>
        <div>
            <h2 class="text-lg font-semibold mb-2">Productos Más Vendidos</h2>
            <?php if(count($productosMasVendidos)): ?>
                <canvas id="pieChart"></canvas>
            <?php else: ?>
                <div class="text-gray-500">No hay datos para mostrar.</div>
            <?php endif; ?>
        </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
        <div>
            <h2 class="text-lg font-semibold mb-2">Tickets por Estado</h2>
            <?php if(count($ticketsPorEstado)): ?>
                <canvas id="ticketsEstadoChart"></canvas>
            <?php else: ?>
                <div class="text-gray-500">No hay datos para mostrar.</div>
            <?php endif; ?>
        </div>
        <div>
            <h2 class="text-lg font-semibold mb-2">Citas por Mes</h2>
            <?php if(count($citasPorMes)): ?>
                <canvas id="citasMesChart"></canvas>
            <?php else: ?>
                <div class="text-gray-500">No hay datos para mostrar.</div>
            <?php endif; ?>
        </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
            <h2 class="text-lg font-semibold mb-2">Productos Más Pagados</h2>
            <?php if(count($productosMasPagados)): ?>
                <canvas id="productosPagadosChart"></canvas>
            <?php else: ?>
                <div class="text-gray-500">No hay datos para mostrar.</div>
            <?php endif; ?>
        </div>
        <div>
            <h2 class="text-lg font-semibold mb-2">Servicios Más Pagados</h2>
            <?php if(count($serviciosMasPagados)): ?>
                <canvas id="serviciosPagadosChart"></canvas>
            <?php else: ?>
                <div class="text-gray-500">No hay datos para mostrar.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Ventas por Mes
    const ventasPorMes = <?php echo json_encode($ventasPorMes->toArray(), 15, 512) ?>;
    new Chart(document.getElementById('barChart'), {
        type: 'bar',
        data: {
            labels: Object.keys(ventasPorMes).map(m => 'Mes ' + m),
            datasets: [{
                label: 'Ventas',
                data: Object.values(ventasPorMes),
                backgroundColor: '#2E338C',
            }]
        }
    });
    // Productos Más Vendidos
    const productosMasVendidos = <?php echo json_encode($productosMasVendidos->toArray(), 15, 512) ?>;
    new Chart(document.getElementById('pieChart'), {
        type: 'pie',
        data: {
            labels: Object.keys(productosMasVendidos),
            datasets: [{
                data: Object.values(productosMasVendidos),
                backgroundColor: ['#2E338C', '#F2541B', '#4BC0C0', '#FFCE56', '#36A2EB'],
            }]
        }
    });
    // Tickets por Estado
    const ticketsPorEstado = <?php echo json_encode($ticketsPorEstado->toArray(), 15, 512) ?>;
    new Chart(document.getElementById('ticketsEstadoChart'), {
        type: 'doughnut',
        data: {
            labels: Object.keys(ticketsPorEstado),
            datasets: [{
                data: Object.values(ticketsPorEstado),
                backgroundColor: ['#2E338C', '#F2541B', '#4BC0C0', '#FFCE56', '#36A2EB'],
            }]
        }
    });
    // Citas por Mes
    const citasPorMes = <?php echo json_encode($citasPorMes->toArray(), 15, 512) ?>;
    new Chart(document.getElementById('citasMesChart'), {
        type: 'bar',
        data: {
            labels: Object.keys(citasPorMes).map(m => 'Mes ' + m),
            datasets: [{
                label: 'Citas',
                data: Object.values(citasPorMes),
                backgroundColor: '#F2541B',
            }]
        }
    });
    // Productos Más Pagados
    const productosMasPagados = <?php echo json_encode($productosMasPagados->toArray(), 15, 512) ?>;
    new Chart(document.getElementById('productosPagadosChart'), {
        type: 'bar',
        data: {
            labels: Object.keys(productosMasPagados),
            datasets: [{
                label: 'Pagos',
                data: Object.values(productosMasPagados),
                backgroundColor: '#2E338C',
            }]
        }
    });
    // Servicios Más Pagados
    const serviciosMasPagados = <?php echo json_encode($serviciosMasPagados->toArray(), 15, 512) ?>;
    new Chart(document.getElementById('serviciosPagadosChart'), {
        type: 'bar',
        data: {
            labels: Object.keys(serviciosMasPagados),
            datasets: [{
                label: 'Pagos',
                data: Object.values(serviciosMasPagados),
                backgroundColor: '#F2541B',
            }]
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\SaaS\resources\views/dashboard/index.blade.php ENDPATH**/ ?>